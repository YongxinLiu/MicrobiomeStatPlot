

#-随机森林-封装一个函数





#--main function
# You can learn more about package at:
#
#   https://github.com/microbiota/amplicon

#' @title Random forest modeling for microbiome data
#' @description Random forest modeling for microbiome data
#' @param otu OTU/ASV table;
#' @param map Sample metadata;
#' @param tax taxonomy table
#' @param ps phyloseq object of microbiome
#' @param Group column name for groupID in map table.
#' @param optimal important OTU number which selected
#' @param rfcv TURE or FELSE,whether need to do cross-validation
#' @param nrfcvnum Number of cross-validation
#' @param min Circle diagram inner diameter adjustment
#' @param max Circle diagram outer diameter adjustment
#' @details
#' @return list contain ggplot object and table.
#' @author Contact: Tao Wen \email{2018203048@@njau.edu.cn}, Yong-Xin Liu \email{yxliu@@genetics.ac.cn}
#' @references
#'
#' Jingying Zhang, Yong-Xin Liu, Na Zhang, Bin Hu, Tao Jin, Haoran Xu, Yuan Qin, Pengxu Yan, Xiaoning Zhang, Xiaoxuan Guo, Jing Hui, Shouyun Cao, Xin Wang, Chao Wang, Hui Wang, Baoyuan Qu, Guangyi Fan, Lixing Yuan, Ruben Garrido-Oter, Chengcai Chu & Yang Bai.
#' NRT1.1B is associated with root microbiota composition and nitrogen use in field-grown rice.
#' Nature Biotechnology, 2019(37), 6:676-684, DOI: \url{https://doi.org/10.1038/s41587-019-0104-4}
#'
#' @examples
#' # data form github
#' result = MicroRF(ps = ps,group  = "Group",optimal = 20,rfcv = TRUE,nrfcvnum = 5,min = -1,max = 5)
#' result[[1]]
#' result[[2]]
#' result[[3]]
#'@export
MicroRF <- function(otu = NULL,tax = NULL,map = NULL,tree = NULL,
                    ps = NULL,group  = "Group",optimal = 20,rfcv = FALSE,nrfcvnum = 5,min = -1,max = 5
                    ){
  ps = inputMicro(otu,tax,map,tree,ps,group  = group)
  map = as.data.frame(sample_data(ps))
  head(map)

  #-scaleing relative abundancce#----
  ps_rela  = transform_sample_counts(ps, function(x) x / sum(x) );ps_rela
  mapping = as.data.frame(sample_data(ps_rela))
  otutab = as.data.frame((vegan_otu(ps_rela)))
  
  # Set classification info.
  otutab$group = factor(mapping$Group)
  
  # set random seed for reproducible reandomforest model
  set.seed(315)
  model_rf= randomForest::randomForest(group ~ ., data=otutab, importance=TRUE, proximity=TRUE)
  print(model_rf)
  
  if (rfcv == TRUE) {
    result = Micro.rfcv(otu = NULL,tax = NULL,map = NULL,tree = NULL ,ps = ps_rela,group  = "Group",optimal = 20,nrfcvnum = 6)
    
    prfcv = result[[1]]# plot rfcv
    # result[[2]]# plotdata
    rfcvtable = result[[3]]# table rfcv
  } else{
    prfcv = NULL
    rfcvtable = NULL
  }
  
  
  #------------k可视化
  ###### inportant OTU picked out and plot
  a=as.data.frame(round(importance(model_rf), 2))
  a$id=row.names(a)
  a2<- dplyr::arrange(a, desc(MeanDecreaseAccuracy))
  row.names(a2)=a2$id
  
  a3=head(a2,n=optimal)
  
  taxonomy <- as.data.frame(vegan_tax(ps))
  tax = taxonomy[rownames(a3),]
  a3 = merge(a3,tax,by = "row.names",all = F)
  row.names(a3) = a3$Row.names
  a3$Row.names = NULL
  
  OTU = vegan_otu(ps_rela)
  ### pice mapping
  design = as.data.frame(sample_data(ps_rela))
  
  #mean abundance by groups
  iris.split <- split(as.data.frame(OTU),as.factor(design$Group))
  iris.apply <- lapply(iris.split,function(x)colMeans(x,na.rm = TRUE))
  norm2 <- do.call(rbind,iris.apply)%>% # combine result
    t()
  colnames(norm2) = paste(colnames(norm2),"mean",sep = "")
  
  
  
  ind_fal = merge(a3,norm2,by = "row.names",all = F)
  head(ind_fal)
  
  
  
  # plot fire bar 1
  
  p1 <- ggplot(a3, aes(x = MeanDecreaseAccuracy, y = reorder(id,MeanDecreaseAccuracy))) +
    geom_point(size=6,pch=20,fill = "blue")+
    geom_segment(aes(yend=id),xend=0,size=3)+
    geom_label(aes(x =MeanDecreaseAccuracy*1.1,  label = Phylum),size = 3)
  
  
  
  # plot 2
  a3<- dplyr::arrange(a3, desc(MeanDecreaseAccuracy))
  a3$iid = paste(1:length(a3$id))
  angle1 = 90 - 360 * ( as.numeric(a3$iid) - 0.5) /length(a3$id)
  a3$id = factor(a3$id,levels = a3$id)
  p2 = a3  %>%
    ggplot(aes(x = factor(id), y = MeanDecreaseAccuracy ,label = Phylum)) +
    geom_bar(stat = 'identity', position = 'dodge',fill = "blue") +
    # scale_fill_manual(values = mi)+
    geom_text(hjust = 0, angle = angle1, alpha = 1) +
    coord_polar() +
    ggtitle('') +
    ylim(c(min,max))+
    theme_void()
  p2
  
  return(list(p1,p2,prfcv,rfcvtable,a3))
}

## rfcv function
# You can learn more about package at:
#
#   https://github.com/microbiota/amplicon

#' @title For cross-validation of microbiome data
#' @description For cross-validation of microbiome data
#' @param otu OTU/ASV table;
#' @param map Sample metadata;
#' @param tax taxonomy table
#' @param ps phyloseq object of microbiome
#' @param Group column name for groupID in map table.
#' @param optimal important OTU number which selected
#' @param rfcv TURE or FELSE,whether need to do cross-validation
#' @param nrfcvnum Number of cross-validation
#' @details
#' @return list contain ggplot object and table.
#' @author Contact: Tao Wen \email{2018203048@@njau.edu.cn}, Yong-Xin Liu \email{yxliu@@genetics.ac.cn}
#' @references
#'
#' Jingying Zhang, Yong-Xin Liu, Na Zhang, Bin Hu, Tao Jin, Haoran Xu, Yuan Qin, Pengxu Yan, Xiaoning Zhang, Xiaoxuan Guo, Jing Hui, Shouyun Cao, Xin Wang, Chao Wang, Hui Wang, Baoyuan Qu, Guangyi Fan, Lixing Yuan, Ruben Garrido-Oter, Chengcai Chu & Yang Bai.
#' NRT1.1B is associated with root microbiota composition and nitrogen use in field-grown rice.
#' Nature Biotechnology, 2019(37), 6:676-684, DOI: \url{https://doi.org/10.1038/s41587-019-0104-4}
#'
#' @examples
#' # data form github
#' result = Micro.rfcv(otu = NULL,tax = NULL,map = NULL,tree = NULL ,ps = ps_rela,group  = "Group",optimal = 20,nrfcvnum = 6)
#' prfcv = result[[1]]# plot rfcv
# result[[2]]# plotdata
#' rfcvtable = result[[3]]# table rfcv
#'@export
Micro.rfcv = function(otu = NULL,tax = NULL,map = NULL,tree = NULL,
                      ps = NULL,group  = "Group",optimal = 20,nrfcvnum = 5){
  ps = inputMicro(otu,tax,map,tree,ps,group  = group)
  otutab = as.data.frame((vegan_otu(ps)))
  # Set classification info.
  otutab$group = factor(mapping$Group)
  
  # rfcv for select···
  n = ncol(otutab)-1
  myotutab_t= otutab[1:n]
  set.seed(315)
  result= rfcv(myotutab_t, otutab$group, cv.fold=5, scale = "log", step = 0.9)
  # with(result, plot(n.var, error.cv, log="x", type="o", lwd=2))
  result1 = result
  error.cv = data.frame(num = result$n.var, error.1 =  result$error.cv)
  for (i in 316:(314+ nrfcvnum)){
    print(i)
    set.seed(i)
    result= rfcv(myotutab_t, otutab$group, cv.fold=5, scale = "log", step = 0.9)
    error.cv = cbind(error.cv, result$error.cv)
  }
  n.var = error.cv$num
  error.cv = error.cv[,2:6]
  colnames(error.cv) = paste('err',1:5,sep='.')
  err.mean = apply(error.cv,1,mean)
  allerr = data.frame(num=n.var,err.mean=err.mean,error.cv)
  head(allerr)
  data <- gather(allerr, key = "group", value = "value",-num)
  head(data)
  
  p <- ggplot() +
    geom_line(data = data,aes(x = num, y = value,group = group), colour = 'grey') +
    geom_line(aes(x = allerr$num, y = allerr$err.mean), colour = 'black') +
    coord_trans(x = "log2") +
    scale_x_continuous(breaks = c(1, 2, 5, 10, 20, 30, 50, 100, 200)) + # , max(allerr$num)
    labs(title=paste('Training set (n = ', dim(otutab)[1],')', sep = ''),
         x='Number of families ', y='Cross-validation error rate') +
    annotate("text", x = optimal, y = max(allerr$err.mean), label=paste("optimal = ", optimal, sep="")) 
  return(list(plot = p,plotdata = data,origdata = allerr))
}


# Roc function
# You can learn more about package at:
#
#   https://github.com/microbiota/amplicon

#' @title Comparison of three machine methods (randomforest,SVM,GLM).
#' @description Comparison of three machine methods (randomforest,SVM,GLM).
#' @param otu OTU/ASV table;
#' @param map Sample metadata;
#' @param tax taxonomy table
#' @param ps phyloseq object of microbiome
#' @param Group column name for groupID in map table.
#' @param repnum Modeling times
#' @details
#' @return list contain ggplot object and table.
#' @author Contact: Tao Wen \email{2018203048@@njau.edu.cn}, Yong-Xin Liu \email{yxliu@@genetics.ac.cn}
#' @references
#'
#' Jingying Zhang, Yong-Xin Liu, Na Zhang, Bin Hu, Tao Jin, Haoran Xu, Yuan Qin, Pengxu Yan, Xiaoning Zhang, Xiaoxuan Guo, Jing Hui, Shouyun Cao, Xin Wang, Chao Wang, Hui Wang, Baoyuan Qu, Guangyi Fan, Lixing Yuan, Ruben Garrido-Oter, Chengcai Chu & Yang Bai.
#' NRT1.1B is associated with root microbiota composition and nitrogen use in field-grown rice.
#' Nature Biotechnology, 2019(37), 6:676-684, DOI: \url{https://doi.org/10.1038/s41587-019-0104-4}
#'
#' @examples
#' result = MicroRoc( ps = ps,group  = "Group")
#' #--提取roc曲线
#' result[[1]]
#' #提取AUC值
#' result[[2]]
#'@export
MicroRoc <- function(otu = NULL,tax = NULL,map = NULL,tree = NULL,
                     ps = NULL,group  = "Group",repnum = 5){
  ps = inputMicro(otu,tax,map,tree,ps,group  = group)
  mapping = as.data.frame(sample_data(ps))
  otutab = as.data.frame(t(vegan_otu(ps)))
  test = as.data.frame(t(otutab))
  test$group = factor(mapping$Group)
  colnames(test) = paste("OTU",colnames(test),sep = "")
  
  # random forest

  test = select(test,OTUgroup,everything())
  train = test
  folds<-createFolds(y=test[,1],k=repnum)
  AUC =c()
  
  max=0
  num=0
  fc<-as.numeric()#fc 为测试数据真实分组信息
  mod_pre<-as.numeric()
  for(i in 1:repnum){
    fold_test<-train[folds[[i]],]
    fold_train<-train[-folds[[i]],]
    model<-randomForest(OTUgroup~.,data=fold_train, importance=TRUE, proximity=TRUE)
    model_pre<-predict(model,newdata = fold_test,type="prob")
    fc<-append(fc,as.factor(fold_test$OTUgroup))
    mod_pre<-append(mod_pre,model_pre[,2])
  }
  
  
  #- pick data and plot
  pred <- prediction(mod_pre, fc)  
  perf <- performance(pred,"tpr","fpr") 
  x <- unlist(perf@x.values)  ##提取x值
  y <- unlist(perf@y.values)
  plotdata <- data.frame(x,y) 
  names(plotdata) <- c("x", "y")
  AUC[1] = paste("rf AUC:",round(performance(pred,'auc')@y.values[[1]],3),sep = " ")
  g0 <- ggplot(plotdata) + 
    geom_path(aes(x = x, y = y, colour = x), size=1,color = "red") + 
    labs(x = "False positive rate", y = "Ture positive rate", title ="Random Forest") 
  df<-cbind(fc,as.numeric(mod_pre))
  #-svm
  max=0
  num=0
  fc<-as.numeric()
  mod_pre<-as.numeric()
  
  for(i in 1:repnum){
    fold_test<-train[folds[[i]],]
    # head(fold_test)
    fold_train<-train[-folds[[i]],]
    model<-svm(OTUgroup~.,data=fold_train,probability=TRUE)
    model
    model_pre<-predict(model,newdata = fold_test,decision.values = TRUE, probability = TRUE)
    fc<-append(fc,as.numeric(fold_test$OTUgroup))
    mod_pre<-append(mod_pre,as.numeric(attr(model_pre, "probabilities")[,2]))
  }
  
  pred <- prediction(mod_pre, fc)  
  perf <- performance(pred,"tpr","fpr") 
  x <- unlist(perf@x.values)  
  y <- unlist(perf@y.values)
  plotdata <- data.frame(x,y) 
  names(plotdata) <- c("x", "y")
  AUC[2] = paste("svm AUC:",round(performance(pred,'auc')@y.values[[1]],3),sep = " ")
  
  
  g1 <- g0 + 
    geom_path(data = plotdata,aes(x = x, y = y, colour = x), size=1,color = "blue") + 
    labs(x = "False positive rate", y = "Ture positive rate", title ="ROC曲线")
  
  df<-cbind(df,cbind(fc,mod_pre))
  
  #GLM
  max=0
  num=0
  fc<-as.numeric()
  mod_pre<-as.numeric()
  for(i in 1:repnum){
    fold_test<-train[folds[[i]],]
    fold_train<-train[-folds[[i]],]
    model<-glm(OTUgroup~.,family='binomial',data=fold_train)
    model
    model_pre<-predict(model,type='response',newdata=fold_test)
    model_pre
    
    fc<-append(fc,fold_test$OTUgroup)
    mod_pre<-append(mod_pre,as.numeric(model_pre))
  }
  
  pred <- prediction(mod_pre, fc)  
  perf <- performance(pred,"tpr","fpr") 
  x <- unlist(perf@x.values)  ##提取x值
  y <- unlist(perf@y.values)
  plotdata <- data.frame(x,y) 
  names(plotdata) <- c("x", "y")
  AUC[3] = paste("GLM AUC:",round(performance(pred,'auc')@y.values[[1]],3),sep = " ")
  
  g2 <- g1 + 
    geom_path(data = plotdata,aes(x = x, y = y, colour = x), size=1,color = "black") + 
    labs(x = "False positive rate", y = "Ture positive rate", title ="ROC曲线") 
  g2
  
  df<-cbind(df,cbind(fc,mod_pre))
  
  
  return(list(g2,AUC,df))
}


