# My Simple Network script
# By Rui. 2020/05/07

warnings('off')

# # 安装包
# install.packages(psych)
# install.packages(reshape2)

# 加载包
library(psych)
library(reshape2)


# 设置工作目录
setwd("C:/Users/Cuenca Coco/Documents/Infromation/Template/Network/1.My simple_version")

# 导入数据(txt)，默认格式：行=Sample，列=OTU/Ev
# 或右侧Import Dataset，注意设置！！！
# OTU/Ev文件：heading=TRUE, col.names=first column！！
# Taxonomy文件：heading=TRUE，col.names=automatic！！


Ev <- read.table("data/data_Ev.txt", sep="\t", header=TRUE, row.names = 1)
OTU <- read.table("data/data_OTU.txt", sep="\t", header=TRUE, row.names = 1)

# 导入节点注释文件
tax <- read.table("data/taxonomy.txt", sep="\t", header=TRUE)
names(tax)[1] <- "Id"
# ==============================================================================================

# 转置数据格式

# # 情形1：单数据OTU-OTU表格时：
# OTU=data_OTU
# OTU=t(OTU)


# 情形2：两数据Ev-OTU表格时:
# Ev=data_Ev
Ev=t(Ev)

# OTU=data_OTU
OTU=t(OTU)
# ==============================================================================================


# 设定关键计算阈值，后面的都不用动了
# OTU筛选百分比丰度
abundance = 0.05
# OTU过多时按丰度筛选
OTU <- OTU[,colSums(OTU)/sum(OTU)>=(abundance/100)]

# 关联阈值
r.cutoff=0.6
p.cutoff=0.05

# ==============================================================================================




# 开始计算，不用修改




# ==============================================================================================


# # 计算r、p(情形1：单数据OTU-OTU表格时)
# occor = corr.test(OTU,
#                   use="pairwise",
#                   method="spearman",  #method=person/spearman/kendall
#                   adjust="fdr",
#                   alpha=0.05)


# 计算r、p(情形2：两数据Ev-OTU表格时)
occor = corr.test(OTU, Ev,
                  use="pairwise",
                  method="spearman",  #method=person/spearman/kendall
                  adjust="fdr",
                  alpha=0.05)
# ==============================================================================================


# 提取相关性矩阵的r、p值
r_matrix = occor$r
p_matrix = occor$p

# 确定物种间存在相互作用关系的阈值，将相关性R矩阵内不符合的数据转换为0
r_matrix[p_matrix>p.cutoff|abs(r_matrix)<r.cutoff] = 0

# 转换数据为长格式
p_value=melt(p_matrix)
r_value=melt(r_matrix)

#将r、p两表合并
r_value=cbind(r_value, p_value$value)

# 删除含r_value=0的行
r_value=subset(r_value, r_value[,3]!=0)

# 删除含r_value=NA的行
r_value=na.omit(r_value)

# 对r表格增补绝对值、正负型等信息
abs=abs(r_value$value)

linktype=r_value$value
linktype[linktype>0]=1
linktype[linktype<0]=-1

r_value=cbind(r_value, abs, linktype)

# 重命名r、p表头
names(r_value) <- c("Source","Target","r_value","p_value", "abs_value", "linktype")
names(p_value) <- c("Source","Target","p_value")

# 输出结果为csv文件
write.csv(r_matrix, file="result/4.corr_matrix.csv")
write.csv(r_value,file="result/5.r_value.csv", row.names = FALSE)
write.csv(p_value,file="result/6.p_value.csv", row.names = FALSE)
write.csv(r_value,file="result/1.边数据.csv", row.names = FALSE)



# ==========================================节点数据==================================================
# 从边文件提取节点并去除重复
node_OTU <- as.data.frame(as.data.frame(r_value[,1])[!duplicated(as.data.frame(r_value[,1])), ])
node_Ev <- as.data.frame(as.data.frame(r_value[,2])[!duplicated(as.data.frame(r_value[,2])), ])

names(node_OTU)="Id"
names(node_Ev)="Id"

# OTU ID和Ev ID合并成节点索引表，用于检索注释信息
list <- rbind(node_Ev, node_OTU)
write.csv(list,file="result/3.node_list.csv", row.names = FALSE)

# 筛选节点对应的注释信息
list = subset(tax,Id %in% list$Id)

# 复制一列当节点Label
list$Label <- list$Id

# 输出结果为csv文件
write.csv(list,file="result/2.节点数据.csv", row.names = FALSE)