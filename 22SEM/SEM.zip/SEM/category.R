#方法1：

library(lavaan)  

# 读取数据  
#mydata <- read.csv("meta.csv", row.names = 1) 
#mydata <- as.data.frame(scale(mydata))
# 创建状态哑变量  
#mydata$status_dummy <- ifelse(mydata$status == 2, 1, 0) # 假设status=2表示枯萎，status=1表示正常  
# 读取数据  
mydata <- read.csv("meta.csv", row.names = 1)  

# 假设status列已经存在，且status=2表示枯萎，status=1表示正常  
# 创建状态哑变量（如果status只有1和2两个值，这一步其实可以省略，直接用status列即可）  
mydata$status_dummy <- ifelse(mydata$status == 2, 1, 0)  

# 获取所有数值变量的名称  
numeric_vars <- names(mydata)[sapply(mydata, is.numeric)]  

# 从数值变量中排除status和status_dummy列  
numeric_vars_to_scale <- numeric_vars[!(numeric_vars %in% c("status", "status_dummy"))]  

# 仅对除status和status_dummy外的数值变量进行标准化  
mydata_scaled <- mydata  
mydata_scaled[, numeric_vars_to_scale] <- as.data.frame(scale(mydata[, numeric_vars_to_scale]))  

# 查看修改后的数据框  
head(mydata_scaled)
# 定义SEM模型，确保潜在变量和观测变量名称不冲突  
model <- '  
  # 测量模型  
  latentBact =~ Bacteria_richness  
  latentFung =~ Fungi_richness  
  latentFAPROTAX =~ FAPROTAX  
  latentFunGuild =~ FunGuild  
    
  # 结构模型 OM + AN + status_dummy    
  latentBact ~  OM   + status_dummy
  latentFung ~ OM    + status_dummy
  latentFAPROTAX ~ OM  + status_dummy
  latentFunGuild ~   OM  + status_dummy
    
  # 如果你想要定义潜在变量之间的关系，可以在这里添加  
  # 例如: latentBact ~~ latentFung（表示两个潜在变量之间的相关性）
  #latentBact ~~ latentFAPROTAX
  #latentFung ~~ latentFunGuild
'  

# 拟合模型  
fit <- sem(model, data = mydata_scaled, int.ov.free = TRUE)  

# 输出模型摘要  
summary(fit)

# 提取系数  
coef(fit)  

# 进行参数显著性检验  
anova(fit) 


# 输出模型摘要到文件  
capture.output(summary(fit),coef(fit),anova(fit), file = "model1.txt")  

# 画出结构方程模型图
library(semPlot)
sem_plot <- semPaths(fit,   
                     what = "est",     
                     edge.label.cex = 0.8,     
                     layout = "spring",     
                     fade = FALSE,     
                     curvePivot = TRUE,     
                     residual = FALSE)  


#方法2：

###### Load Libraries for analysis
library(nlme)
library(lsmeans)
library(piecewiseSEM)
library(car)
library(lavaan)
#
exp_data_func <- read.csv("meta.csv", row.names = 1)

exp_data_func$BactR <- exp_data_func$`Bacteria_richness `
exp_data_func$FungR <- exp_data_func$`Fungi_richness`
exp_data_func$FAPR <- exp_data_func$`FAPROTAX`
exp_data_func$FunG <- exp_data_func$`FunGuild`

# +AN+AP+AK+pH      
psem_cat<-psem(
  lme(Bacteria_richness ~ OM + AN , 
       random =~ 1|Soiltype, data=exp_data_func, method="ML"),
  lme(Fungi_richness ~ OM + AN, 
      random =~ 1|Soiltype, data=exp_data_func, method="ML"),
  lme(FAPROTAX ~ Bacteria_richness, 
      random =~ 1|Soiltype, data=exp_data_func, method="ML"),
  lme(FunGuild ~ OM + Fungi_richness + AN, 
      random =~ 1|Soiltype, data=exp_data_func, method="ML"),
  lme(Withered ~ OM + Bacteria_richness + AN ,
      random =~ 1|Soiltype, data=exp_data_func, method="ML"),
  lme(Normal ~ Bacteria_richness + AN + OM + FAPROTAX, 
      random =~ 1|Soiltype, data=exp_data_func, method="ML"),
  Normal %~~% Withered,#%<~>% %~~%
  data=exp_data_func
)

summary(psem_cat)
# 获取summary的输出  
sum_output <- capture.output(summary(psem_cat))  

# 将AIC、卡方等输出保存为TXT文件  
writeLines(sum_output, "psem_cat_summary.txt")

#提取系数估计值
coefs(psem_cat)
# 获取模型的系数  
model_coefs <- coefs(psem_cat)  

# 将系数保存为model2.txt文件  
write.table(model_coefs, file="model2.txt", sep="\t", row.names=FALSE, quote=FALSE)  

# 绘制模型图
plot(psem_cat)


