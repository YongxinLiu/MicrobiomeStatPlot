# 绘制聚类丰度图形
#
# The function named 'alpha_barplot'
# which draw barplot + error bar + test alphabet with alpha and metadata, and reture a ggplot2 object
#
# You can learn more about package at:
#
#   https://github.com/microbiota/amplicon

#' @title Plotting alpha diversity barplot for each group with anova statistics
#' @description Combine sample clustering and drawing stacked histograms of microbial categories
#' @param otu OTU/ASV table;
#' @param map Sample metadata;
#' @param tax taxonomy table
#' @param rep Number of sample replicates measured in each group
#' @param Top Select the number of microorganisms with the highest relative abundance in all samples
#' @param hcluter_method hcluter method
#' @param Group column name for groupID in map table.
#' @param cuttree cut number
#' @details
#' hcluter method is same an function hcluster
#' @return list contain ggplot object and table.
#' @author Contact: Tao Wen \email{2018203048@@njau.edu.cn}, Yong-Xin Liu \email{yxliu@@genetics.ac.cn}
#' @references
#'
#' Jingying Zhang, Yong-Xin Liu, Na Zhang, Bin Hu, Tao Jin, Haoran Xu, Yuan Qin, Pengxu Yan, Xiaoning Zhang, Xiaoxuan Guo, Jing Hui, Shouyun Cao, Xin Wang, Chao Wang, Hui Wang, Baoyuan Qu, Guangyi Fan, Lixing Yuan, Ruben Garrido-Oter, Chengcai Chu & Yang Bai.
#' NRT1.1B is associated with root microbiota composition and nitrogen use in field-grown rice.
#' Nature Biotechnology, 2019(37), 6:676-684, DOI: \url{https://doi.org/10.1038/s41587-019-0104-4}
#'
#' @examples
#' # data form github
#' metadata = read.table("http://210.75.224.110/github/EasyAmplicon/data/metadata.tsv", header=T, row.names=1, sep="\t", comment.char="", stringsAsFactors = F)
#' otutab = read.table("http://210.75.224.110/github/EasyAmplicon/data/otutab.txt", header=T, row.names=1, sep="\t", comment.char="", stringsAsFactors = F)
#' taxonomy = read.table("http://210.75.224.110/github/EasyAmplicon/data/taxonomy.txt", header=T, row.names=1, sep="\t", comment.char="", stringsAsFactors = F)
#'result <-  cluMicro.bar (dist = "bray",
#'                         otu = otutab,
#'                         tax = taxonomy,
#'                         map = metadata,
#'                         rep = 6 ,# 重复数量是6个
#'                         Top = 10, # 提取丰度前十的物种注释
#'                         tran = TRUE, # 转化为相对丰度值
#'                         hcluter_method = "complete",
#'                         cuttree = 3,
#'                         Group = "Group"
#')
#'@export




cluMicro.bar <- function(dist = "bray",
         otu = NULL,
         tax = NULL,
         map = NULL,
         rep = 6 ,# 重复数量是6个
         Top = 10, # 提取丰度前十的物种注释
         tran = TRUE, # 转化为相对丰度值
         hcluter_method = "complete",
         Group = "Group",
         cuttree = 3){
  
  j = "Phylum" # 使用门水平绘制丰度图表
  # Extract only those ID in common between the two tables
  idx = rownames(otu) %in% rownames(tax)
  otu = otu[idx,]
  tax = tax[rownames(otu),]
  
  map <- map[Group]
  colnames(map) = "Group"
  map$ID = row.names(map)
  
  ps =phyloseq(sample_data(map),otu_table(as.matrix(otu), taxa_are_rows=TRUE), tax_table(as.matrix(tax)))
  # phyloseq(ps)对象标准化
  ps1_rela = phyloseq::transform_sample_counts(ps, function(x) x / sum(x) )
  # 导出OTU表
  otu = as.data.frame(t(vegan_otu(ps1_rela)))
  
  #计算距离矩阵
  unif = phyloseq::distance(ps1_rela , method = dist)
  # 聚类树，method默认为complete
  hc <- stats::hclust(unif, method = hcluter_method )
  
  #  take grouping with hcluster tree
  clus <- cutree(hc, cuttree )
  # 提取树中分组的标签和分组编号
  d = data.frame(label = names(clus), 
                 member = factor(clus))
  # eatract mapping file
  map = as.data.frame(sample_data(ps))
  # 合并树信息到样本元数据
  dd = merge(d,map,by = "row.names",all = F)
  row.names(dd) = dd$Row.names 
  dd$Row.names = NULL
  
  
  
  # ggtree绘图 #----
  p  = ggtree(hc) %<+% dd + 
    geom_tippoint(size=5, shape=21, aes(fill= Group, x=x)) + 
    geom_tiplab(aes(color = Group,x=x * 1.2), hjust=1)
  p
  
  # 按照分类学门(j)合并
  psdata = ps1_rela %>% tax_glom(taxrank = j)
  
  # 转化丰度值
  if (tran == TRUE) {
    psdata = psdata%>% transform_sample_counts(function(x) {x/sum(x)} )
  }
  
  #--提取otu和物种注释表格
  otu = otu_table(psdata)
  tax = tax_table(psdata)
  
  
  #--按照指定的Top数量进行筛选与合并
  for (i in 1:dim(tax)[1]) {
    if (row.names(tax)[i] %in% names(sort(rowSums(otu), decreasing = TRUE)[1:Top])) {
      tax[i,j] =tax[i,j]
    } else {
      tax[i,j]= "Other"
    }
  }
  tax_table(psdata)= tax
  
  ##转化为表格
  Taxonomies <- psdata %>% psmelt()
  # head(Taxonomies)
  Taxonomies$Abundance = Taxonomies$Abundance * 100
  
  Taxonomies$OTU = NULL
  colnames(Taxonomies)[1] = "id"
  
  head(Taxonomies)
  
  p <- p + ggnewscale::new_scale_fill()
  p
  p1 <- facet_plot(p, panel = 'Stacked Barplot', data = Taxonomies, geom = geom_barh,mapping = aes(x = Abundance, fill = Phylum),color = "black",stat='identity' )   
  p1
  
  grotax <- Taxonomies %>% 
    group_by(Group,Phylum) %>% 
    summarise(Abundance = mean(Abundance))
  
  #--绘制分组的聚类结果
  ps1_rela = phyloseq::transform_sample_counts(ps, function(x) x / sum(x) )
  #按照分组合并OTU表格
  hc = phyloseq::merge_samples(ps1_rela, "Group",fun = mean) %>%
    phyloseq::distance(method = dist) %>%
    stats::hclust( method = hcluter_method )
  
  
  #  take grouping with hcluster tree
  clus <- cutree(hc, cuttree )
  # 提取树中分组的标签和分组编号
  d = data.frame(label = names(clus), 
                 member = factor(clus))
  # eatract mapping file
  map = as.data.frame(sample_data(phyloseq::merge_samples(ps1_rela, "Group",fun = mean)))
  # 合并树信息到样本元数据
  dd = merge(d,map,by = "row.names",all = F)
  row.names(dd) = dd$Row.names 
  dd$Row.names = NULL
  
  
  
  # ggtree绘图 #----
  p3  = ggtree(hc) %<+% dd + 
    geom_tippoint(size=5, shape=21, aes(fill= member, x=x)) + 
    geom_tiplab(aes(color = member,x=x * 1.2), hjust=1)
  p3
  p3 <- p3 + ggnewscale::new_scale_fill()
  
  p4 <- facet_plot(p3, panel = 'Stacked Barplot', data = grotax, geom = geom_barh,mapping = aes(x = Abundance, fill = Phylum),color = "black",stat='identity' )   
  p4
  
  return(list(p,p1,p3,p4,Taxonomies))
}



vegan_otu =  function(physeq){
  OTU =  otu_table(physeq)
  if(taxa_are_rows(OTU)){
    OTU =  t(OTU)
  }
  return(as(OTU,"matrix"))
}

vegan_tax <-  function(physeq){
  tax <-  tax_table(physeq)
  
  return(as(tax,"matrix"))
}

