[TOC]

## 前言
在微生物数据分析过程中，经常需要对某几组样本中共有或特有的OTU或微生物进行可视化。基于此需求，通常可以选择Venn图等进行可视化。然而，当分组信息过多，Venn的展示能力及可读性则有所下降，因此作者可以采用Venn图的升级版本——Upset Plot.

在本教程中，我将从菌群OTU表或者feature.tab开始，无需在代码外整理数据，从而直接实现用Venn或Upset Plot对集合信息进行可视化。进行可视化将使用VennDiagram和UpsetR等R包。

除了以上两个R包以外，还有ImageGP，yyplot,VennPainter，VennMaster以及TBtools的WonderfulVenn等软件或网站可供选择。详见：https://cloud.tencent.com/developer/article/1423035 

此外，需要指出的是，本文撰写过程中涉及到的描述和代码参考了诸多生信和可视化方面专家的前期工作，不具备开创性特色，不过搜集整理并让代码适用于直接对微生物分析中的OTU表格的分析。可以说本文的撰写，确实是站在巨人的肩上。文尾将对参考内容进行整理，此处不一一致谢了。

其他：本文所有示例数据和代码均已经上传Github：https://github.com/JerryHnuPKUPH/OTU2V-UpPlot

## Venn图简介

维恩图（英语：Venn diagram），又称Venn图。是十九世纪英国数学家约翰·维恩（John Venn）发明，用于展示集合之间大致关系的一类图形。其中圈或椭圆重合（overlap）的部分就是集合与集合间元素的交集，非重叠部分则为特定集合特有元素。

![image](https://bkimg.cdn.bcebos.com/pic/5d6034a85edf8db10a0e924f0b23dd54564e74fd?x-bce-process=image/resize,m_lfit,w_268,limit_1/format,f_jpg)


## Venn和Upset Plot对比

Venn和Upset Plot均可用于集合共有和特有元素信息进行可视化，但是当数据分组过多（>4），Venn图看起来会非常杂乱，而Upset plot可以展示≥5个以上分组的集合信息。

**总结起来：**

1）分组<5，Venn图更清晰；

2）分组≥5，Upset Plot更清晰；

3） Upset Plot展示方式更多元。



## VennDiagram和UpsetR的数据要求

值得注意的是，VennDiagram和UpsetR的数据要求并不相同，前者要求适用`list`输入以各组为集合的元素变量名,有几个分组就输入几个集合;而后者以元素变量名为行名，用数字0和1代表元素在分组集合中存在与否，数据输入是以数据框的形式输入。

  **VennDiagram的数据类型**   |  **UpsetR的数据类型** 
| ID   | Set1 | Set2 | Set3 |      | Var. | Set1 | Set2 | Set3 |
| ---- | ---- | ---- | ---- | ---- | ---- | ---- | ---- | ---- |
| 1    | A    | A    | A    |      | A    | 1    | 1    | 1    |
| 2    | B    |      | B    |      | B    | 1    | 0    | 1    |
| 3    | C    | C    | C    |      | C    | 1    | 1    | 1    |
| 4    | D    | D    |      |      | D    | 1    | 1    | 0    |
| 5    | E    |      | E    |      | E    | 1    | 0    | 1    |
| 6    | F    |      |      |      | F    | 1    | 0    | 0    |


## 文献解读
### 例1. 两组样本

#### 文章介绍
本文是浙江大学医学院附属儿童医院风湿免疫-变态反应科和中科院遗传发育所合作完成，于2020年4月7日发表在《BMC Genomics》上的论文。文章的主要内容为幼年特发性关节炎患儿肠道菌群的相关研究。

![image](https://mmbiz.qpic.cn/mmbiz_png/RozUCQWmoogaU7U3z2QlNDRuHah7s7iaraDg86QABnEH4Ooqful8UZlbclT41v5ia2t5NHiarWjGBGpTj0ibj87GkQ/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)

#### 图形解读

图1：两组多样性比较. (A)分别是Chao 1和香农指数箱线图，两组差异显著。(B)是韦恩图，显示了两组有83个属是相同的，但是JIA组有3个属是独有的，对照组有8个属是独有的。(C) PCoA图，每个点代表一个样本，可见两种颜色的点聚集情况有不同，提示β多样性有差异。(D) 发育树，显示了丰度＞0.3%的OTU，不同的“门”用颜色区分。

#### 论文摘要

**背景和目的**：近年来的研究发现幼年特发性关节炎（juvenile idiopathic arthritis，JIA）患儿肠道菌群有紊乱的情况，但是前面这些研究均未匹配年龄、性别、BMI等因素，结果不是很一致。作者进行了一个性别、年龄、BMI频率匹配的横断面研究（cross-sectional study），分析了JIA患儿肠道菌群的特征，评估了其在临床预测中的作用。

**方法**：JIA患儿40例，对照组42例，年龄1~16岁，采用16S rDNA测序。用随机森林的方法进行生物标记识别，用受试者工作曲线（ROC）和决策曲线分析（decision curve analysis，DCA）方法评估模型效果。

**结果**：病例组α多样性下降；两组间β多样性指标Bray-Curtis dissimilarity有显著差异；病例组有4个属的细菌下降，这些菌与常用风湿指标呈负相关，而且这些菌均为产短链脂肪酸细菌；用随机森林方法筛选出12个属具有作为生物标记的潜力，用12个属构建的随机森林模型用于识别患者和非患者的ROC下面积是0.7975，DCA显示这个模型具有临床使用价值。

**结论**：JIA患儿存在肠道菌群改变，以4个产短链脂肪酸属细菌下降为特征；这4个属下降与更严重的风湿指标相关；12个属构建的模型可用于临床预测。

### 例2. 三组样本

#### 文章介绍

本文是2019年5月10日由中科院遗传发育所白洋组与JIC的Anne Osbourn组合作在拟南芥代谢物调控根系微生物组领域取得重大突破，成果以Article形式于5月10日在线发表于Science杂志，海南大学罗杰教授对本工作的意义进行点评。详细报导请点击下方链接：https://mp.weixin.qq.com/s?__biz=MzUzMjA4Njc1MA==&mid=2247488285&idx=2&sn=bad4fb6ed8f202f4dd6393309f34ce8f&scene=21#wechat_redirect 

![image](https://mmbiz.qpic.cn/mmbiz_png/RozUCQWmoohxicdBN6mTfpoCT0N1IIbx8uVJwlzrfUnqMwTQ6yfrUNaxyGxRWGBicgootxTCjiaz6sjWDlf0A1PAA/640?wx_fmt=png&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)

#### 图形解读

图4. 三萜通路的突变体特异调控的根系细菌类群：(A) 基于Bray-Curtis距离的有监督主坐标轴分析展示基因型对菌群调控的效应。(B) 不同基因型门水平的根系微生物组成。其中Proteobacteria门由于丰度高于50%，进而划分为Alpha, Beta, Delta 和 Gemma四个纲进行展示。#号表示Bacteroidetes与野生型Col-0存在显著差异（P < 0.05，Wilcoxon秩和检验）；(C, D) 维恩图展示了的拟南芥三萜突变体中下调(C)或富集(D)的OTUs，与水稻和小麦与拟南芥野生型相比变化的OTUs大量重叠

#### 论文摘要

**背景和目的**: 植物进化和适应的特征之一是产生特殊的代谢物。植物特有的代谢产物具有生态功能，介导植物与其环境的相互作用。虽然微生物可以对植物生长和适应性产生多方面的影响，但植物如何组装和调节其微生物组尚不清楚。了解这一过程背后的影响因素和机制将为可持续农业和植物微生物组工程开辟道路。据估计，植物利用大约20%的光合产物碳源来制造根源性有机分子。然而，是否（如果是的话，哪一种）专化的代谢物能够指导特定的根微生物群的组装仍然未知。

**理性**: 三萜类化合物是植物特异的代谢物，它们的功能包括在植物防御、信号，及抗微生物活性。它们是植物天然产物中数量最大且结构最多样的家族之一。小芥菜类植物拟南芥基因组包括四个根系特异表达而途径未知的三萜生物合成基因簇。植物生物合成基因簇是在强大的选择压力下形成，生产的相关小分子在生物的进化和生态中起重要作用。已有研究表明这些拟南芥的基因簇在应对病原体的防御反应中起作用，表明这些三萜合成基因簇可能调控拟南芥根系微生物组。

**结果**： 作者已经阐明了一个拟南芥根特异表达的代谢网络，它由功能上不同的三萜生物合成基因簇组成，并由外部分散的基因参与，它们主要编码多种酰基转移酶和乙醇脱氢酶。这个代谢网络具有合成50多种以前未知的根系代谢产物的潜力。考虑到作者检测到的非挥发性根系代谢物总数（约300种）是一个相对较大的数字。作者对三种不同的根系三萜代谢产物的生物合成途径进行了鉴定：拟南芥宁素(thalianin)、拟南芥宁基脂肪酸酯(thalianyl fatty acid esters)和拟南芥啶素(arabidin)。对拟南芥这些化合物的生物合成突变体的根微生物组的分析表明，与野生型相比它们的根微生物组成和多样性发生了变化。与分类上较远物种水稻和小麦的根系细菌分布相比较，支持这种特殊的三萜生物合成网络在介导拟南芥特定微生物组建立中的作用。接下来，作者在体外测试了纯化的拟南芥根系三萜化合物和具有代表性的三萜混合物对从拟南芥根系微生物组中分离出的19个分类多样的细菌菌株活性的影响。发现这些化合物确实可以选择性地调节这些细菌的生长，正调控和负调控的例子很明显。不同三萜类化合物对不同菌株生长的调节作用与拟南芥Col-0和三萜突变体根中不同菌种的相对丰度差异相关。此外，还发现一些根系细菌能够选择性地代谢某些三萜类化合物（如拟南芥脂肪酸酯），并利用分解产物作为碳源进行增殖。

**结论**: 作者证实拟南芥产生一系列特殊的三萜类物质，指导拟南特异性微生物组的建成与维持，使其能够根据自身目的来塑造和调整根内和根周围的微生物群落。作者推测，植物界内的代谢多样性可能为塑造微生物组适应宿主需求中提供了交流和识别的基础，可以部分解释植物特异代谢物存在意义。本研究为植物根系微生物组工程化提供了机会，为研究根系微生物组在植物生长和健康中的作用奠定了基础。


### 例3. 四组样本

#### 文章介绍

本文是北京大学人民医院消化内科刘玉兰教授课题组于2020年2月发表在炎症性肠病研究的专业杂志《Inflammatory bowel disease》的文章。主要内容是关于溃疡性结肠炎患者使用5-氨基水杨酸（5-ASA）治疗后肠道真菌菌群的变化特点研究。

![image](https://github.com/JerryHnuPKUPH/OTU2V-UpPlot/blob/master/IBD_Fig3.png)

#### 图形解读

图3. 在验证性研究中组特异性真菌微生物群。A、Upset Plot显示每组的OTU数量。B、各组的指示物种。利用indicspecies软件包对属级真菌丰度进行了分析。点的形状代表组内otu的富集（三角）或减少（圆点），点的大小代表真菌属的丰度。（C-E）组间OTU丰度差异分析：（C）治疗前的炎性粘膜（preI）与治疗前的非炎性粘膜（preN）；（D）5-ASA治疗后的炎性粘膜（postI）与治疗前的炎性粘膜（preI）；（E）5-ASA治疗后的炎性粘膜（postI）与5-ASA治疗后的非炎性粘膜（postN）。采用EdgeR包进行差异分析,两组之间的差异用曼哈顿图展示。点形状显示前一组的OTUs较后一组增加（Enriched）、降低(Depleted)或不显著(NotSig)。点大小表示otu的丰度。

#### 文章摘要

**背景和目的**：目前治疗方案对溃疡性结肠炎（UC）患者真菌微生物群的影响尚不清楚。在此，作者旨在阐明5-氨基水杨酸（5-ASA）治疗对UC患者肠道真菌菌群的影响。

**方法**： 共有57名UC患者了一组探索性研究，其中未治疗组20人，5-ASA治疗组37人。作者采用ITS1-2 rRNA测序分析比较了这两组患者肠道粘膜样本中的真菌谱。此外，在20名未治疗UC患者中，有10名接受了随访，规律使用5-ASA治疗后被纳入了验证性研究。

**结果**：作者评估了这些患者在5-ASA治疗前后真菌微生物群的纵向差异，验证性研究结果与探索性研究结果一致。其中，Ascomycota是非炎性和炎症性粘膜的优势菌门。在门水平上，5-ASA治疗前炎症粘膜中的子囊菌较非炎性粘膜中有所减少。在属水平上，炎性粘膜中**Scytalidium**, *Morchella*和*Paecilomyces*等病原菌增多，腐殖酸菌和Wickerhamomyces减少。5-ASA治疗后，Ascomycota和*Wickerhamomyces*增加，而*Scytalidium*、*Fusarium*、*Morchella*和*Paecilomyces*在非炎性和炎症性粘膜中均减少。此外，治疗前炎症粘膜中细菌-真菌相互联系被破坏，而5-ASA治疗不但改变了UC患者的组特异性真菌微生物群，还恢复了细菌-真菌之间密切的相关性。

**结论**：结果表明，5-ASA治疗后，炎症粘膜中真菌的多样性和组成发生了改变，细菌-真菌的相关性得以恢复。




## 软件安装

```
# 设置清华源镜像
site="https://mirrors.tuna.tsinghua.edu.cn/CRAN"
package_list = c("VennDiagram","UpSetR")

# 判断R包加载是否成功来决定是否安装后再加载
for(p in package_list){
  if(!suppressWarnings(suppressMessages(require(p, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))){
    install.packages(p, repos=site)
    suppressWarnings(suppressMessages(library(p, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))
  }
}
```
## 前期数据处理

```

# 读取OTUtab或各级profiling.tab
Data = read.table("genus.profile.txt", header=T, row.names= 1, sep="\t", comment.char="") 

# 读取 design.txt 和 mapping file，第三列信息随意，没有回报错
design = read.table("design.txt", header=T, row.names= 1, sep="\t", comment.char="")

# 匹配 design和 Data的行名，用于进一步处理数据
index = rownames(design) %in% colnames(Data) 
design = design[index,]
Data = Data[,rownames(design)] 
Data_t = t(Data)

# 求均值(Sum值也行)
Data_t2 = merge(design, Data_t, by="row.names")
# 删除来自design的非分组信息
Data_t2 = Data_t2[,c(-1,-3)]

# Define a function of mean
Data_mean = aggregate(Data_t2[,-1], by=Data_t2[1], FUN=mean)
# 整合各组均值 
Data4Pic = as.data.frame(do.call(rbind, Data_mean)[-1,])
group = Data_mean$group
# 为均值表添加列名（分组信息）
colnames(Data4Pic) = group
Data4Pic=as.data.frame(Data4Pic)

# 将数据表中>0的数值替换为1，数值>0则OTU或各级数据在分组中有出现，替换为1是用于可视化的数据准备
Data4Pic[Data4Pic>0]=1

# 保存数据，用于以后分析需要
write.table(Data4Pic,"data4venn.txt",sep = "\t")


```


## 使用VennDiagram绘制Venn图

**注意:** VennDiagram的图形绘制结果无法在Rstudio中直接呈现，而是直接生成图形并保存于工作目录。

**参数设置：**`x=list()`指定集合，由于VennDiagram要求输入以各组为集合的元素变量名，因此，作者将提取`Data4Pic`各组中数值`=1`的变量名作为数据输入的集合。
`filename=`指定图形绘制的结果保存的名称。
`imagetype=`参数设置图片生成的类型，但遗憾的是它只能指定`npg`,`tiff`等矢量图格式。
为了能够将图形绘制的结果保存为pdf格式，作者将`filename=`指定为`NULL`,并使用`grid.draw`函数输出图像。


```
pdf(file="Genus_venn.pdf") #设置pdf文件，用于存储绘制的图形
p1 <- venn.diagram(
  x=list(
    A=row.names(Data4Pic[Data4Pic$A==1,]),#提取各组中`=1`的行名。需根据自己的分组，调整list中的分组情况
    B=row.names(Data4Pic[Data4Pic$B==1,]),
    C=row.names(Data4Pic[Data4Pic$C==1,]),
    D=row.names(Data4Pic[Data4Pic$D==1,])),
             filename = NULL, #不指定保存的文件名，也不指定`imagetype`
             lwd = 3,
             alpha = 0.6,
             label.col = "white", #设置字体颜色
             cex = 1.5,
             fill = c("dodgerblue", "goldenrod1", "darkorange1", "seagreen3"), #设置各组的颜色
             cat.col = c("dodgerblue", "goldenrod1", "darkorange1", "seagreen3"),
             fontfamily = "serif", #设置字体
             fontface = "bold",
             cat.fontfamily = "serif",
             cat.fontface = "bold",
             margin = 0.05)
p1
grid.draw(p1) #使用`grid.draw`函数在`venn.diagram`绘图函数外绘制图形
dev.off()
```
图形绘制结果

![image](https://github.com/JerryHnuPKUPH/OTU2V-UpPlot/blob/master/Genus_venn.png)

## 使用UpsetR绘制Upset Plot

为方便代码兼容R3.6和R4.0版本，再进行一次数据处理

```
# 目的是将'Data4Pic'的行名转换为'numeric'的行号
row.names(Data4Pic) <- 1:nrow(Data4Pic)
```
随后进行数据可视化

```
# Upset plot的基本图形绘制
pdf(file="Genus_Upsetplot.pdf", height = 4, width = 6)
p2 <-upset(Data4Pic, sets = colnames(Data4Pic),order.by = "freq")
p2
dev.off()
```
**Upset参数解释1**
`example`：存放矩阵的变量名称；`set`：所需要的集合名称；`mb.ratio`：调整上下两部分的比例;`order.by`：排序方式，`freq`为按频率排序;

图形绘制结果

![image](https://github.com/JerryHnuPKUPH/OTU2V-UpPlot/blob/master/Genus_Upsetplot.png)


```
# 使用Queries参数绘制Upset Plot
pdf(file="Genus_Upsetplot_indiv.pdf",height = 4, width = 10)
p3<-upset(Data4Pic, sets = colnames(Data4Pic), mb.ratio = c(0.55, 0.45), order.by = "freq",
      queries = list(list(query=intersects, params=list("A", "B"), color="purple", active=T), 
                     list(query=intersects, params=list("C", "D", "A"), color="green", active=T), 
                     list(query=intersects, params=list("B", "C", "A", "D"), color="blue", active=T)), 
      nsets = 3, number.angles = 0, point.size = 4, line.size = 1, mainbar.y.label = "Number of Shared Genus",
      sets.x.label = "General Number in Each Group", text.scale = c(1.5, 1.5, 1.5, 1.5, 1.5, 1.5))
p3
dev.off()

```
**Upset参数解释2**

`queries`：查询函数，用于对指定列添加颜色;`param: list`:query作用于哪个交集；`color`：每个query都是一个list，里面可以设置颜色,没设置的话将调用包里默认的调色板；`active`：被指定的条形图：`TRUE`显示颜色，`FALSE`在条形图顶端显示三角形;`nset`：集合数量，也可用set参数指定具体集合;`number.angles`：上方条形图数字角度，0为横向，90为竖向，但90时不在正上方;`point.size`：下方点阵中点的大小；`line.size`：下方点阵中每个线的粗细;`mainbar.y.label`：上方条形图Y轴名称;`sets.x.label`：左下方条形图X轴名称;`text.scale`：六个数字控制关系见；`query.legend`;指定query图例的位置…… 


图形绘制结果

![image](https://github.com/JerryHnuPKUPH/OTU2V-UpPlot/blob/master/Genus_Upsetplot_indiv.png?raw=true)

**更多参数信息**

此外，UpsetR还提供了`attribute.plots`参数,可绘制`histogram`,`scatter_plot`,`boxplot.summary`等图形的绘制。可以根据自己数据的需要进行配置数据，详细可见：https://cran.r-project.org/web/packages/UpSetR/vignettes/

## Reference
[1] Qian X, Liu YX, Ye X, Zheng W, Lv S, Mo M, Lin J, Wang W, Wang W, Zhang X et al: Gut microbiota in children with juvenile idiopathic arthritis: characteristics, biomarker identification, and usefulness in clinical prediction. BMC Genomics 2020, 21(1):286.

[2] Huang AC, Jiang T, Liu YX, Bai YC, Reed J, Qu B, Goossens A, Nutzmann HW, Bai Y, Osbourn A: A specialized metabolic network selectively modulates Arabidopsis root microbiota. Science 2019, 364(6440).

[3] Jun X, Ning C, Yang S, Zhe W, Na W, Yifan Z, Xinhua R, Yulan L: Alteration of Fungal Microbiota After 5-ASA Treatment in UC Patients. Inflamm Bowel Dis 2020, 26(3):380-390.

[4] https://www.cnblogs.com/jessepeng/p/11610055.html

[5] https://www.jianshu.com/p/285b4ac66768

[6] https://cran.r-project.org/web/packages/UpSetR/vignettes/

[7] https://blog.csdn.net/tuanzide5233/article/details/83109527